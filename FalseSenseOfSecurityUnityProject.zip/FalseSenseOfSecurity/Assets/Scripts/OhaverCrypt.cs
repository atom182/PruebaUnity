﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using UnityEngine.UI;


public class OhaverCrypt : MonoBehaviour {

	private string[,] dictionary = new string[30,3]{
														{"A", ".-", "2"},
														{"B", "-...", "4"},
														{"C", "-.-.", "4"},
														{"D", "-..", "3"},
														{"E", ".", "1"},
														{"F", "..-.", "4"},
														{"G", "--.", "3"},
														{"H", "....", "4"},
														{"I", "..", "2"},
														{"J", ".---", "4"},
														{"K", "-.-", "3"},
														{"L", ".-..", "4"},
														{"M", "--", "2"},
														{"N", "-.", "2"},
														{"O", "---", "3"},
														{"P", ".--.", "4"},
														{"Q", "--.-", "4"},
														{"R", ".-.", "3"},
														{"S", "...", "3"},
														{"T", "-", "1"},
														{"U", "..-", "3"},
														{"V", "...-", "4"},
														{"W", ".--", "3"},
														{"X", "-..-", "4"},
														{"Y", "-.--", "4"},
														{"Z", "--..", "4"},
														{"_", "..--", "4"},
														{".", "---.", "4"},
														{",", ".-.-", "4"},
														{"?", "----", "4"},
													};

	char[] textToDecrypt;
	string[] lengthInfo;
	string[] lengthInfoInvert;
	List<string> morseCodeList =  new List<string>();
	List<string> lengthInfoList = new List<string>();
	List<string> letterCodeList = new List<string>();
	string textDecrypted;
	public Text messageCodeDecrypted;


	void Awake(){
		
		textToDecrypt = ReadText ();
		ToMorse ();
		InvertLengthInformation ();
		textDecrypted = CodeDescryption ();
		CreateText (textDecrypted);

		print ("Hecho");

	}

	/*************************************************
	 * Lee el texto crifrado y el texto se divide en 
	 * arreglo un arreglo de chars
	 * *************************************************/

	public char[] ReadText(){
		string pathText = Application.dataPath+"/Resources/Crypt.txt";
		if(File.Exists(pathText) == false){
			StreamWriter sw = File.CreateText (pathText);
			sw.WriteLine ("AKADTOF_IBOETATUK_IJN");
			sw.Close ();
		}
		StreamReader readedText = new StreamReader (pathText);
		string contentText = readedText.ReadToEnd ();
		readedText.Close ();
		char[] textSlashed = contentText.ToCharArray ();

		return textSlashed;
	}

	/***********************************************
	 * Cambia las letras del texto por codigo morse
	 * ********************************************/

	public void ToMorse(){
		
		foreach(char c in textToDecrypt){
			
			for(int i = 0; i < 30; i++){
				if (dictionary[i,0].Equals(c.ToString())) {
					letterCodeList.Add (dictionary [i,0]);
					morseCodeList.Add (dictionary [i, 1]);
					lengthInfoList.Add (dictionary [i,2]);
				}
			}
		}

	}

	/**************************************************
	 * Invierte la cadena de longitud de caracteres
	 * ************************************************/

	public void InvertLengthInformation(){
		lengthInfo = lengthInfoList.ToArray ();
		lengthInfoInvert = new string[lengthInfo.Length];
		int invertCount = lengthInfo.Length;
		for(int i = 0; i < lengthInfo.Length ; i++){
			lengthInfoInvert [invertCount-1] = lengthInfo [i];
			invertCount--;
		}
	}

	/**********************************************
	 * Desencripta el codigo pasando el texto 
	 * morse completo, se transforma a arreglo de 
	 * char y se recorre cada casilla del arreglo 
	 * de char y se convierte a letra.
	 * *******************************************/

	public string CodeDescryption(){
		string morseCodeText = "";
		string morseLetter= "";
		string realText = "";
		char[] morseCodeSlashed;
		bool repeat = true;
		int count = 0;
		int countMorseLetter = 0;


		foreach(string s in morseCodeList){
			morseCodeText += s;
		}

		morseCodeSlashed = morseCodeText.ToCharArray ();

		while(repeat){
			if (count <= lengthInfoInvert.Length-1) {
				for (int i = 0; i < int.Parse (lengthInfoInvert [count]); i++) {
					morseLetter += morseCodeSlashed [countMorseLetter];
					countMorseLetter++;
				}
				//print (morseLetter);

		
				for (int i = 0; i < 30; i++) {
					if (morseLetter.Equals (dictionary [i, 1])) {
						realText += dictionary [i, 0];
					}
				}
				count++;
				morseLetter = "";
			} 
			else {
				repeat = false;
			}
		}
		return realText;
	}

	/*****************************************
	 * Se crea el archivo con el texto
	 * descifrado
	 * **************************************/

	public void CreateText(string textDecrypted){
		string path = Application.dataPath + "/Resources/Decrypt.txt";
		StreamWriter sw = File.CreateText (path);
		sw.Write (textDecrypted);
		sw.Close ();

	}

	public void ShowMessage(){
		messageCodeDecrypted.text = textDecrypted;
	}

	public void QuitGame(){
		Application.Quit();
	}
}